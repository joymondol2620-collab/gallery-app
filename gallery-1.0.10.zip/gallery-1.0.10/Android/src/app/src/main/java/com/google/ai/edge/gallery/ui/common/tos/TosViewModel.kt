/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.ai.edge.gallery.ui.common.tos

import androidx.lifecycle.ViewModel
import com.google.ai.edge.gallery.data.DataStoreRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/** ViewModel responsible for managing terms of services related tasks. */
@HiltViewModel
open class TosViewModel @Inject constructor(private val dataStoreRepository: DataStoreRepository) :
  ViewModel() {
  fun getIsTosAccepted(): Boolean {
    return dataStoreRepository.isTosAccepted()
  }

  fun acceptTos() {
    dataStoreRepository.acceptTos()
  }

  fun getIsGemmaTermsOfUseAccepted(): Boolean {
    return dataStoreRepository.isGemmaTermsOfUseAccepted()
  }

  fun acceptGemmaTermsOfUse() {
    dataStoreRepository.acceptGemmaTermsOfUse()
  }
}
